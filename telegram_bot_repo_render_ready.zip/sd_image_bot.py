
import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

import os
REPLICATE_API_TOKEN = os.environ.get("REPLICATE_API_TOKEN")
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Welcome! Send me an image prompt and I'll generate an AI image for you.")

async def generate_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    prompt = update.message.text.strip()
    await update.message.reply_text("Generating image... please wait.")

    try:
        response = requests.post(
            "https://api.replicate.com/v1/predictions",
            headers={
                "Authorization": f"Token {REPLICATE_API_TOKEN}",
                "Content-Type": "application/json"
            },
            json={
                "version": "db21e45e84aebc49343a27e37b2333c7b9c76f4ae6d86cd3ab4f1f91db2a55ef",
                "input": {"prompt": prompt}
            }
        )
        prediction = response.json()
        get_url = prediction['urls']['get']

        import time
        while True:
            poll = requests.get(get_url, headers={"Authorization": f"Token {REPLICATE_API_TOKEN}"})
            poll_data = poll.json()
            if poll_data['status'] == 'succeeded':
                break
            elif poll_data['status'] == 'failed':
                await update.message.reply_text("Image generation failed.")
                return
            time.sleep(1)

        image_url = poll_data['output'][0]
        await update.message.reply_photo(photo=image_url, caption="Here is your AI image!")
    
    except Exception as e:
        await update.message.reply_text(f"Error: {e}")

app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, generate_image))

print("Bot is running...")
app.run_polling()
